#ifndef NextPower_H_        /* Include guard */
#define NextPower_H_

float nextPower2(int x);    /*function decleration */

#endif 
