#ifndef OTime_H_ 
#define OTime_H_


double* forOTime(int s);

#endif
