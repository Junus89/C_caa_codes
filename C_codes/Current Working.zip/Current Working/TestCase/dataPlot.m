

A=importdata('FDPressureSpectrum.txt');
A1=A(:,1);
A2=A(:,2);
stem(A1,A2,'r','o');

