#ifndef LINSPACE_H_   /* Include guard */
#define LINSPACE_H_

double* linSpace(int Tnum);  /*Function declaration */

#endif 
