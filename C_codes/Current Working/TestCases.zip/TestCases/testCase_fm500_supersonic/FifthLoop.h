#ifndef FifthLoop_H_
#define FifthLoop_H_
void fifthLoop(int TNum, int DSNum, double OmegaR, double Gamma, double C_0, double *MaX, double *MaY, double *MaZ, double DX, double DY, double DZ, double DR, double OX, double OY,\
	 double OZ, double Theta, double *DataXR, double *DataYR, double *DataZR, double *DOrX, double *DOrY, double *DOrZ, double *DOr, double *DORStar, double *DOR, double *DORStarX,\
		 double *DORStarY, double *DORStarZ, double *DORX, double *DORY, double *DORZ, double *RGama);
#endif
